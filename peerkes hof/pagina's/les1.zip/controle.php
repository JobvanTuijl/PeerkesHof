    <?php
    $conn = new mysqli("localhost", "root", "", "peerkeshof");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
        $naam = strtolower($_POST['name']);
        echo 'hallo';
        $sql = "SELECT wachtwoord FROM gebruikers WHERE naam = '$naam'";
        $result = $conn->query($sql);
        if ($_POST['password']== $result) 
           { 
            header("Location: Peerkeshof.html");
            } 
        else
           { 
            header("Location: Peerkeshof.html");
            }  
        $conn->close();
        ?>